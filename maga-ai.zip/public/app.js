let currentLang = 'tg';
let currentTheme = 'dark';
let activeChatId = 'chat_1';
let chats = [];
let attachedFile = null;
let recognition = null;
let isListening = false;

const i18n = {
  tg: {
    newChat: 'Чати нав',
    tools: 'Абзорҳо',
    welcomeTitle: 'Хуш омадед ба MAGA AI!',
    welcomeDesc: 'Ёвари зеҳни сунъии шумо бо забони тоҷикӣ. Савол диҳед ё аз кортҳо оғоз кунед:',
    placeholder: 'Саволи худро нависед...',
    thinking: 'MAGA AI дар ҳоли фикрронӣ...'
  },
  ru: {
    newChat: 'Новый чат',
    tools: 'Инструменты',
    welcomeTitle: 'Добро пожаловать в MAGA AI!',
    welcomeDesc: 'Ваш умный ИИ-помощник. Задайте вопрос или выберите карточку:',
    placeholder: 'Задайте вопрос...',
    thinking: 'MAGA AI думает...'
  },
  en: {
    newChat: 'New Chat',
    tools: 'Tools',
    welcomeTitle: 'Welcome to MAGA AI!',
    welcomeDesc: 'Your intelligent AI assistant. Ask a question or start with a card:',
    placeholder: 'Ask anything...',
    thinking: 'MAGA AI is thinking...'
  }
};

// LocalStorage
function loadState() {
  const savedChats = localStorage.getItem('maga_chats');
  if (savedChats) {
    try { chats = JSON.parse(savedChats); } catch (e) { chats = []; }
  }
  if (!chats.length) {
    chats = [{ id: 'chat_' + Date.now(), title: 'Чати аввал', messages: [] }];
  }
  activeChatId = chats[0].id;

  const savedTheme = localStorage.getItem('maga_theme') || 'dark';
  setTheme(savedTheme);

  const savedLang = localStorage.getItem('maga_lang') || 'tg';
  changeLang(savedLang);

  renderChatList();
  renderMessages();
}

function saveChats() {
  localStorage.setItem('maga_chats', JSON.stringify(chats));
}

function getActiveChat() {
  return chats.find(c => c.id === activeChatId) || chats[0];
}

function renderChatList() {
  const list = document.getElementById('chatList');
  list.innerHTML = '';
  chats.forEach(c => {
    const item = document.createElement('div');
    item.style.cssText = `padding: 8px 10px; border-radius: 8px; margin-bottom: 4px; font-size: 12px; cursor: pointer; display: flex; justify-content: space-between; align-items: center; background: ${c.id === activeChatId ? 'var(--border)' : 'transparent'}`;
    item.innerHTML = `<span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"><i class="fa-regular fa-message" style="margin-right: 6px;"></i>${c.title}</span><i class="fa-solid fa-trash" style="opacity: 0.5; font-size: 11px;" onclick="deleteChat('${c.id}', event)"></i>`;
    item.onclick = () => selectChat(c.id);
    list.appendChild(item);
  });
}

function selectChat(id) {
  activeChatId = id;
  renderChatList();
  renderMessages();
  if (window.innerWidth <= 768) toggleSidebar();
}

function newChat() {
  const newId = 'chat_' + Date.now();
  chats.unshift({ id: newId, title: 'Чати нав', messages: [] });
  activeChatId = newId;
  saveChats();
  renderChatList();
  renderMessages();
  if (window.innerWidth <= 768) toggleSidebar();
}

function deleteChat(id, e) {
  e.stopPropagation();
  chats = chats.filter(c => c.id !== id);
  if (!chats.length) newChat();
  else {
    activeChatId = chats[0].id;
    saveChats();
    renderChatList();
    renderMessages();
  }
}

function renderMessages() {
  const chat = getActiveChat();
  const box = document.getElementById('messagesBox');
  const welcome = document.getElementById('welcomeCard');

  if (!chat.messages.length) {
    box.innerHTML = '';
    box.appendChild(welcome);
    welcome.style.display = 'block';
    return;
  }

  welcome.style.display = 'none';
  box.innerHTML = '';

  chat.messages.forEach(m => {
    const bubble = document.createElement('div');
    const isUser = m.role === 'user';
    bubble.className = `bubble ${isUser ? 'bubble-user' : (m.role === 'error' ? 'bubble-error' : 'bubble-bot')}`;

    let fileHtml = m.fileName ? `<div style="font-size: 11px; opacity: 0.8; margin-bottom: 4px;"><i class="fa-solid fa-paperclip"></i> ${m.fileName}</div>` : '';
    bubble.innerHTML = `${fileHtml}<div>${escapeHtml(m.content)}</div>`;

    if (!isUser && m.role !== 'error') {
      const copyBtn = document.createElement('button');
      copyBtn.className = 'btn-icon';
      copyBtn.style.cssText = 'width: 24px; height: 24px; font-size: 11px; margin-top: 6px;';
      copyBtn.innerHTML = '<i class="fa-regular fa-copy"></i>';
      copyBtn.onclick = () => {
        navigator.clipboard.writeText(m.content);
        copyBtn.innerHTML = '<i class="fa-solid fa-check" style="color: var(--accent-cyan);"></i>';
        setTimeout(() => copyBtn.innerHTML = '<i class="fa-regular fa-copy"></i>', 2000);
      };
      bubble.appendChild(copyBtn);
    }

    box.appendChild(bubble);
  });

  box.scrollTop = box.scrollHeight;
}

function escapeHtml(text) {
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

async function handleSubmit(e) {
  if (e) e.preventDefault();
  const input = document.getElementById('chatInput');
  const text = input.value.trim();
  if (!text && !attachedFile) return;

  const chat = getActiveChat();
  if (!chat.messages.length) {
    chat.title = text ? text.slice(0, 24) : (attachedFile ? attachedFile.name : 'Гуфтугӯ');
  }

  const userMsg = { role: 'user', content: text, fileName: attachedFile ? attachedFile.name : null };
  chat.messages.push(userMsg);
  input.value = '';

  const fileToSend = attachedFile;
  removeFile();

  renderMessages();
  saveChats();

  // Loader
  const box = document.getElementById('messagesBox');
  const loadingBubble = document.createElement('div');
  loadingBubble.className = 'bubble bubble-bot';
  loadingBubble.id = 'loadingIndicator';
  loadingBubble.innerHTML = `<i class="fa-solid fa-circle-notch fa-spin" style="color: var(--accent-cyan); margin-right: 6px;"></i> ${i18n[currentLang].thinking}`;
  box.appendChild(loadingBubble);
  box.scrollTop = box.scrollHeight;

  try {
    let reply = '';
    const model = document.getElementById('modelSelect').value;
    const temperature = document.getElementById('tempRange').value;

    if (fileToSend) {
      const fd = new FormData();
      fd.append('file', fileToSend);
      fd.append('prompt', text || 'Ин файлро мукаммал таҳлил кунед.');
      fd.append('model', model);

      const res = await fetch('/api/analyze-file', { method: 'POST', body: fd });
      const data = await res.json();
      if (!data.success) throw new Error(data.error);
      reply = data.reply;
    } else {
      const history = chat.messages.slice(-8).map(m => ({ role: m.role, content: m.content }));
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, history, model, temperature })
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error);
      reply = data.reply;
    }

    loadingBubble.remove();
    chat.messages.push({ role: 'assistant', content: reply });
  } catch (err) {
    loadingBubble.remove();
    chat.messages.push({ role: 'error', content: err.message || 'Хатогӣ рух дод.' });
  }

  renderMessages();
  saveChats();
}

function handleKeyDown(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    handleSubmit();
  }
}

function sendQuickPrompt(prompt) {
  document.getElementById('chatInput').value = prompt;
  handleSubmit();
}

function handleFileSelect(e) {
  if (e.target.files && e.target.files[0]) {
    attachedFile = e.target.files[0];
    document.getElementById('fileBadge').style.display = 'inline-flex';
    document.getElementById('fileName').innerText = attachedFile.name;
  }
}

function removeFile() {
  attachedFile = null;
  document.getElementById('fileBadge').style.display = 'none';
  document.getElementById('fileInput').value = '';
}

// Voice STT
function toggleVoice() {
  const Speech = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Speech) return alert('Браузери шумо сабти овозро дастгирӣ намекунад.');
  const btn = document.getElementById('micBtn');

  if (isListening) {
    if (recognition) recognition.stop();
    return;
  }

  recognition = new Speech();
  recognition.lang = currentLang === 'tg' ? 'tg-TJ' : (currentLang === 'ru' ? 'ru-RU' : 'en-US');
  recognition.onstart = () => { isListening = true; btn.style.color = 'var(--danger)'; };
  recognition.onresult = (e) => {
    document.getElementById('chatInput').value = e.results[0][0].transcript;
  };
  recognition.onend = () => { isListening = false; btn.style.color = 'inherit'; };
  recognition.start();
}

// Generate Image (Flux Free)
async function generateImage() {
  const prompt = document.getElementById('imagePrompt').value.trim();
  const box = document.getElementById('imageResult');
  const btn = document.getElementById('genImgBtn');
  if (!prompt) return;

  btn.disabled = true;
  btn.innerText = 'Дар ҳоли эҷод...';
  box.innerHTML = '<i class="fa-solid fa-spinner fa-spin" style="font-size: 20px; color: var(--accent-cyan);"></i>';

  try {
    const res = await fetch('/api/generate-image', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt })
    });
    const data = await res.json();
    if (data.imageUrl) {
      box.innerHTML = `<img src="${data.imageUrl}" style="max-width: 100%; border-radius: 12px; margin-bottom: 8px;"><br><a href="${data.imageUrl}" target="_blank" download="maga-ai.jpg" class="btn btn-secondary" style="font-size: 11px;"><i class="fa-solid fa-download"></i> Боргирӣ</a>`;
    }
  } catch (e) {
    box.innerHTML = '<span style="color: var(--danger);">Хато дар тавлиди тасвир.</span>';
  } finally {
    btn.disabled = false;
    btn.innerText = 'Эҷод кардан';
  }
}

// Admin stats
async function checkAdminStats() {
  const secret = document.getElementById('adminSecretInput').value.trim();
  const box = document.getElementById('adminStatsBox');
  if (!secret) return;

  try {
    const res = await fetch('/api/admin/stats', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ adminSecret: secret })
    });
    const data = await res.json();
    if (data.success) {
      box.innerHTML = `Вақти фаъолият: <b>${data.stats.uptimeFormatted}</b><br>Чатҳо: <b>${data.stats.chatRequests}</b> | Расмҳо: <b>${data.stats.imageRequests}</b><br>Gemini API: <b style="color: ${data.stats.geminiConfigured ? '#10b981' : '#f59e0b'}">${data.stats.geminiConfigured ? 'Пайваст ✅' : 'Танзим нашудааст ⚠️'}</b>`;
    } else {
      box.innerHTML = `<span style="color: var(--danger);">${data.error}</span>`;
    }
  } catch (e) {
    box.innerHTML = '<span style="color: var(--danger);">Пайваст нашуд.</span>';
  }
}

// UI Helpers
function toggleSidebar() {
  const sb = document.getElementById('sidebar');
  const bd = document.getElementById('sidebarBackdrop');
  sb.classList.toggle('open');
  bd.classList.toggle('active');
  document.getElementById('sidebarCloseBtn').style.display = window.innerWidth <= 768 ? 'inline-flex' : 'none';
}

function openModal(id) { document.getElementById(id).classList.remove('hidden'); }
function closeModal(id) { document.getElementById(id).classList.add('hidden'); }

function toggleTheme() {
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  setTheme(newTheme);
}

function setTheme(theme) {
  currentTheme = theme;
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('maga_theme', theme);
  const icon = document.getElementById('themeIcon');
  if (icon) icon.className = theme === 'dark' ? 'fa-solid fa-moon' : 'fa-solid fa-sun';
}

function changeLang(lang) {
  currentLang = lang;
  localStorage.setItem('maga_lang', lang);
  document.getElementById('langSelect').value = lang;
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (i18n[lang] && i18n[lang][key]) el.innerText = i18n[lang][key];
  });
  document.getElementById('chatInput').placeholder = i18n[lang].placeholder;
}

window.addEventListener('DOMContentLoaded', loadState);

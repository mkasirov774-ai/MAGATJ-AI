# MAGA AI — Веб-барномаи Зеҳни Сунъӣ

Платформаи муосири чати зеҳни сунъӣ бо забони тоҷикӣ, русӣ ва англисӣ.
Бо истифода аз Google Gemini API, таҳлили файлҳо, тавлиди расми ройгон ва мутобиқ ба телефонҳои Android.

## 🚀 Нашри сайт дар Render (Free Tier):
1. Ин ҷузвдон ё файли `maga-ai.zip`-ро кушода, ба GitHub бор кунед.
2. Ба [dashboard.render.com](https://dashboard.render.com) рафта, **New +** -> **Web Service**-ро интихоб кунед.
3. Танзимот:
   - **Environment:** `Node`
   - **Build Command:** `npm install`
   - **Start Command:** `node server.js`
   - **Plan:** `Free`
4. Дар бахши **Environment Variables** калиди `GEMINI_API_KEY`-ро илова намоед.
5. Тугмаи **Deploy Web Service**-ро пахш кунед.

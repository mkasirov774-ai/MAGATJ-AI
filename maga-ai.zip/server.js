const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');
const multer = require('multer');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const ADMIN_SECRET = process.env.ADMIN_SECRET || 'maga_admin_2026';

const stats = {
  startTime: Date.now(),
  chatRequests: 0,
  fileRequests: 0,
  imageRequests: 0,
  errors: 0
};

app.use(cors());
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024 }
});

// Ёрирасон барои Gemini API
async function callGemini(contents, systemInstruction, config = {}) {
  if (!GEMINI_API_KEY) {
    throw new Error('NO_API_KEY');
  }

  const model = config.model || 'gemini-1.5-flash';
  const temperature = config.temperature !== undefined ? parseFloat(config.temperature) : 0.7;
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${GEMINI_API_KEY}`;

  const payload = {
    contents: contents,
    generationConfig: {
      temperature: temperature,
      maxOutputTokens: 2048
    }
  };

  if (systemInstruction) {
    payload.systemInstruction = {
      parts: [{ text: systemInstruction }]
    };
  }

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const message = errorData.error?.message || `HTTP ${response.status}: ${response.statusText}`;
    throw new Error(`GEMINI_API_ERROR: ${message}`);
  }

  const data = await response.json();
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) {
    throw new Error('Модел ҷавоби холӣ баргардонд.');
  }
  return text;
}

// 1. Чат бо AI
app.post('/api/chat', async (req, res) => {
  stats.chatRequests++;
  try {
    const { message, history = [], systemInstruction, model, temperature } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ success: false, error: 'Паём холӣ аст.' });
    }

    const defaultSystem = 'Шумо MAGA AI ҳастед — ёвари ҳушманди касбии зеҳни сунъӣ. Ба саволҳо бо забони адабӣ, равон, дӯстона ва илмии тоҷикӣ посух диҳед. Агар бо русӣ ё англисӣ муроҷиат кунанд, бо ҳамон забон ҷавоб гардонед. Дар фанҳои риёзиёт, физика, химия ва барномасозӣ мисолҳои равшан оред.';

    const contents = [];
    for (const item of history) {
      if (item.role && item.content) {
        contents.push({
          role: item.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: item.content }]
        });
      }
    }

    contents.push({
      role: 'user',
      parts: [{ text: message }]
    });

    const reply = await callGemini(contents, systemInstruction || defaultSystem, { model, temperature });

    res.json({
      success: true,
      reply: reply,
      modelUsed: model || 'gemini-1.5-flash'
    });
  } catch (err) {
    stats.errors++;
    if (err.message === 'NO_API_KEY') {
      return res.status(503).json({
        success: false,
        error: 'Калиди GEMINI_API_KEY дар сервер танзим нашудааст. Лутфан онро дар бахши Environment Variables дар Render ворид кунед.',
        code: 'NO_API_KEY'
      });
    }
    res.status(500).json({ success: false, error: err.message });
  }
});

// 2. Таҳлили файл (Тасвирҳо ва Ҳуҷҷатҳо)
app.post('/api/analyze-file', upload.single('file'), async (req, res) => {
  stats.fileRequests++;
  try {
    const file = req.file;
    const prompt = req.body.prompt || 'Лутфан ин файлро ба таври муфассал ба забони тоҷикӣ таҳлил намоед.';
    const model = req.body.model || 'gemini-1.5-flash';

    if (!file) {
      return res.status(400).json({ success: false, error: 'Ҳеҷ файле бор нашудааст.' });
    }

    const mime = file.mimetype;
    const contents = [];

    if (mime.startsWith('image/')) {
      contents.push({
        role: 'user',
        parts: [
          { text: prompt },
          {
            inlineData: {
              mimeType: mime,
              data: file.buffer.toString('base64')
            }
          }
        ]
      });
    } else {
      const textContent = file.buffer.toString('utf-8');
      contents.push({
        role: 'user',
        parts: [
          { text: `[Файл: ${file.originalname}, Навъ: ${mime}]
[Мундариҷа]:
${textContent.slice(0, 50000)}

[Супориш]: ${prompt}` }
        ]
      });
    }

    const reply = await callGemini(contents, 'Шумо мутахассиси таҳлили файлҳои MAGA AI ҳастед.', { model });

    res.json({
      success: true,
      reply: reply,
      fileName: file.originalname
    });
  } catch (err) {
    stats.errors++;
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3. Тавлиди ройгони тасвир (Flux)
app.post('/api/generate-image', (req, res) => {
  stats.imageRequests++;
  try {
    const { prompt } = req.body;
    if (!prompt) return res.status(400).json({ success: false, error: 'Тавсифи расм лозим аст.' });

    const encoded = encodeURIComponent(prompt.trim());
    const seed = Math.floor(Math.random() * 1000000);
    const imageUrl = `https://image.pollinations.ai/prompt/${encoded}?width=1024&height=1024&seed=${seed}&nologo=true&model=flux`;

    res.json({ success: true, imageUrl, prompt });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Хато дар тавлиди тасвир.' });
  }
});

// 4. Санҷиши саломатӣ
app.get('/api/health', (req, res) => {
  const uptimeSeconds = Math.floor((Date.now() - stats.startTime) / 1000);
  res.json({
    status: 'ok',
    app: 'MAGA AI',
    uptime: `${uptimeSeconds} сония`,
    geminiConfigured: Boolean(GEMINI_API_KEY)
  });
});

// 5. Омори маъмурӣ
app.post('/api/admin/stats', (req, res) => {
  const secret = req.headers['x-admin-key'] || req.body.adminSecret;
  if (!secret || secret !== ADMIN_SECRET) {
    return res.status(401).json({ success: false, error: 'Рамзи нодуруст.' });
  }

  const uptimeSeconds = Math.floor((Date.now() - stats.startTime) / 1000);
  res.json({
    success: true,
    stats: {
      uptimeSeconds,
      uptimeFormatted: `${Math.floor(uptimeSeconds / 60)} дақиқа`,
      chatRequests: stats.chatRequests,
      fileRequests: stats.fileRequests,
      imageRequests: stats.imageRequests,
      geminiConfigured: Boolean(GEMINI_API_KEY)
    }
  });
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Сервери MAGA AI дар порти ${PORT} фаъол шуд!`);
});
